const github = {
    baseURL: "https://api.github.com/graphql",
    username: "ARBUCHELI",
    headers: {
        "Content-Type": "application/json",
        Authorization: "bearer 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"
    }
}

export default github;